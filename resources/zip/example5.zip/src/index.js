import { message, messageDOM } from './message';
import info from './title.txt';

message(info);
messageDOM(info);
